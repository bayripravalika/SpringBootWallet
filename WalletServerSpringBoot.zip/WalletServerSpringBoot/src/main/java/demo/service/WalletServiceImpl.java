package demo.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.WalletRepo;

@Service(value="service")
public class WalletServiceImpl implements WalletService {

	
	private WalletRepo repo;
	
	@Autowired
	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}

	public Customer createAccount(String name, String mobileNo, BigDecimal amount) {
		Customer customer = new Customer(name,mobileNo, new Wallet(amount));
		if(repo.save(customer)){
			return customer;
		}
		return null;
	}

	public Customer showBalance(String mobileNo) {
		
		return repo.findOne(mobileNo);
	}


}
