package demo.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import demo.beans.Customer;
import demo.service.WalletService;

@RestController
public class WalletController {

	@Autowired
	private WalletService service;

	@RequestMapping(value="/", method=RequestMethod.GET)
	public Customer test(){
		Customer c = service.createAccount("Sagar", "9850276767", new BigDecimal(2000));
		return c;
	}

	@RequestMapping(value="/createCustomer", method=RequestMethod.GET)
	public Customer createAccount(){		
		Customer c = service.createAccount("Sagar", "9850276767", new BigDecimal(2000));
		return c;
	}

	@RequestMapping(value="/showBalance", method=RequestMethod.GET)
	public Customer showBalance(){
		
		return service.showBalance("9850276767");
	}




}
